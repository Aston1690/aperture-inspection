# Aperture native design import

Prepared because the Figma connector reached its Starter quota. **This importer has not been executed or visually verified in Figma.** The linked Figma file is still empty.

1. In the Figma desktop editor, open Plugins → Development → Import plugin from manifest and select `manifest.json` in this folder.
2. Run **Aperture — editable design import**, then click Import.
3. It creates separate pages for foundations/components, 24 product screens and six wireframes. Text remains editable; common buttons use component instances; colours use local variables. Specimen images remain image fills, with vector annotations.
4. Inspect the resulting Figma screens against the supplied PNGs. Font availability is checked before import. No network permissions are requested.

The import builds new pages each time. Run it once or remove previously imported pages before retrying. The real app is the working prototype; Figma navigation covers the main review path.
